#ifndef NODO_CORE_TRANSACTION_TYPE_HPP
#define NODO_CORE_TRANSACTION_TYPE_HPP

#include <string>

namespace nodo::core {

/*
 * TransactionType defines every state-changing action planned for Nodo.
 *
 * Important:
 * A transaction type is not only a label. It determines validation rules,
 * required signatures, and how the transaction will affect the ledger.
 */
enum class TransactionType {
    TRANSFER,
    MINT_REWARD,
    LOCK_SECURITY,
    UNLOCK_SECURITY,
    VALIDATOR_REGISTER,
    VALIDATOR_VOTE,
    PENALTY,
    BURN,
    STAKE_DEPOSIT,
    STAKE_WITHDRAW,
    STAKE_TOP_UP,
    VALIDATOR_EXIT_REQUEST,
    VALIDATOR_UNJAIL_REQUEST,
    GOVERNANCE_PROPOSE,
    GOVERNANCE_VOTE
};

std::string transactionTypeToString(TransactionType type);
TransactionType transactionTypeFromString(const std::string& value);

bool isMintTransaction(TransactionType type);
bool isSecurityLockTransaction(TransactionType type);
bool requiresUserSignature(TransactionType type);
bool isStakingTransaction(TransactionType type);
bool isValidatorLifecycleTransaction(TransactionType type);
bool isGovernanceTransaction(TransactionType type);

} // namespace nodo::core

#endif